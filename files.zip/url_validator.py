# ============================================================
# analyzer/url_validator.py — URL Validation Module
#
# PURPOSE: Before analyzing anything, we must confirm the
# input is actually a valid URL. Garbage in = garbage out.
#
# SOC RELEVANCE: In a SOC, URLs come from email headers,
# proxy logs, SIEM alerts — they're not always clean.
# This module sanitizes and validates before analysis.
# ============================================================

import re                    # Regular expressions for pattern matching
import validators            # Third-party library for URL validation
from urllib.parse import urlparse  # Python built-in URL parser


def normalize_url(url: str) -> str:
    """
    Normalize the URL so our checks work consistently.
    
    - Strips leading/trailing whitespace (common in copy-paste)
    - Adds 'http://' if no scheme is present
    
    Example:
        'google.com'        → 'http://google.com'
        '  https://evil.com' → 'https://evil.com'
    """
    url = url.strip()  # Remove accidental spaces

    # If URL has no scheme (http/https), add http:// so urlparse works correctly
    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    return url


def is_valid_url(url: str) -> bool:
    """
    Check if the URL is structurally valid.
    
    Uses the 'validators' library which checks:
    - Has a valid scheme (http/https)
    - Has a valid domain format
    - Proper structure overall
    
    Returns True if valid, False if not.
    """
    result = validators.url(url)  # Returns True or a ValidationFailure object
    return result is True         # We explicitly check for True


def extract_url_parts(url: str) -> dict:
    """
    Break a URL into its components using Python's built-in urlparse.
    
    For 'https://login.secure-paypal.com/verify?user=1&code=abc':
        scheme   → 'https'
        netloc   → 'login.secure-paypal.com'
        path     → '/verify'
        query    → 'user=1&code=abc'
    
    SOC RELEVANCE: Attackers hide malicious domains in subdomains.
    Breaking the URL apart lets us inspect each piece independently.
    """
    parsed = urlparse(url)  # Parse the URL into components

    # Extract the domain without 'www.' prefix for cleaner analysis
    domain = parsed.netloc.lower()
    if domain.startswith("www."):
        domain = domain[4:]  # Remove 'www.' (4 characters)

    return {
        "scheme":   parsed.scheme,   # http or https
        "domain":   domain,          # The main host/domain
        "path":     parsed.path,     # Everything after the domain
        "query":    parsed.query,    # Query string parameters
        "full_url": url              # The complete original URL
    }


def validate_and_parse(raw_url: str) -> tuple:
    """
    Master function that combines normalization, validation, and parsing.
    
    Returns a tuple: (is_valid: bool, parts: dict, normalized_url: str)
    
    Usage:
        valid, parts, url = validate_and_parse("paypal-login.evil.com/verify")
    """
    normalized = normalize_url(raw_url)      # Step 1: Clean it up
    valid      = is_valid_url(normalized)    # Step 2: Check if valid
    parts      = extract_url_parts(normalized) if valid else {}  # Step 3: Parse if valid

    return valid, parts, normalized
